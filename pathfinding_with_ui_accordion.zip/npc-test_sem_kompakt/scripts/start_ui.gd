class_name StartUI
extends CanvasLayer
## Shown once at launch: lets the player pick Race or Life mode, how many
## Obstacles to spawn, and which pathfinding algorithm(s) should run,
## before the actual run starts. Everytime start_pressed signal is emitted, the current
## grids are rebuilt/spawned in main.gd
##
## Algorithm identifiers ("astar", "dstar_lite", "jps") and the mode string
## ("race"/"life") are plain strings rather than enums: main.gd is the only
## place that needs to turn them into actual objects/behavior.

signal start_pressed(obstacle_count: int, algorithms: Array[String], mode: String)

# UI Related 
@onready var panel = $PanelContainer
@onready var toggle_button = $ToggleButton

@onready var _race_mode_button: Button = $PanelContainer/VBoxContainer/ModeContainer/RaceModeButton
@onready var _life_mode_button: Button = $PanelContainer/VBoxContainer/ModeContainer/LifeModeButton
@onready var _obstacle_count_box: SpinBox = $PanelContainer/VBoxContainer/ObstacleCountBox
@onready var _astar_check: CheckBox = $PanelContainer/VBoxContainer/AStarCheck
@onready var _dstar_lite_check: CheckBox = $PanelContainer/VBoxContainer/DStarLiteCheck
@onready var _jps_check: CheckBox = $PanelContainer/VBoxContainer/JPSCheck
@onready var _start_button: Button = $PanelContainer/VBoxContainer/StartButton

# Tween duration
const TWEEN_DURATION: float = 0.4

# Animation constants 
var is_open: bool = true
var open_pos: Vector2
var close_pos: Vector2

func _ready() -> void:
	
	# Set Panel related properties	
	panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	toggle_button.pressed.connect(_on_toggle_menu)
	_sync_layout_position()
	
	PhysicsServer2D.set_active(true) # Normalizing physics checks
	var viewport = get_viewport()
	self.custom_viewport = viewport
	
	await get_tree().process_frame
	# Cache positions based on default left wide layout
	open_pos  = panel.position
	close_pos = Vector2(-panel.size.x, panel.position.y)
	
	# Connect events to objects
	
	var main_node = get_parent() as Node2D
	if main_node: 
		main_node.window_layout_changed.connect(_on_window_layout_changed)
	
	_start_button.pressed.connect(_on_start_button_pressed)
	toggle_button.pressed.connect(_on_toggle_menu)


func _on_start_button_pressed() -> void:
	start_pressed.emit(int(_obstacle_count_box.value), _selected_algorithms(), _selected_mode())
	
	await get_tree().process_frame
	slide_in()

func _on_toggle_menu() -> void: 
	if is_open: 
		slide_in()
	else: 
		slide_out()
	
	
## Handles real-time adjustments when the dashboard expands the window space
func _on_window_layout_changed() -> void:
	# Await a layout frame to ensure the engine scales the root window first
	await get_tree().process_frame
	
	# Update the window to reflect on the changes when displaying a dashboard
	var window_width = get_viewport().get_visible_rect().size.x
	var window_height = get_viewport().get_visible_rect().size.y
	
	# Recalculate X anchor dynamically depending on state to eliminate layout gap
	if is_open:
		panel.position.x = window_width - panel.size.x
		toggle_button.position.x = panel.position.x - toggle_button.size.x
	else:
		panel.position.x = window_width
		toggle_button.position.x = window_width - toggle_button.size.x
		
	# Recalculate  y center 
	toggle_button.position.y = (window_height / 2.0) - (toggle_button.size.y / 2.0)

func _selected_mode() -> String:
	return "life" if _life_mode_button.button_pressed else "race"

## Every algorithm whose checkbox is currently ticked. Can be empty, main.gd
## simply spawns no NPC at all in that case.
func _selected_algorithms() -> Array[String]:
	var algorithms: Array[String] = []
	if _astar_check.button_pressed:
		algorithms.append("astar")
	if _dstar_lite_check.button_pressed:
		algorithms.append("dstar_lite")
	if _jps_check.button_pressed:
		algorithms.append("jps")
	return algorithms
	
## Slide menu in 
func slide_in() -> void:
	
	if not is_open: 
		return 
	is_open = false
	
	# Lock inputs so buttons can't be clicked when hidden
	panel.process_mode = PROCESS_MODE_DISABLED
	toggle_button.text = "◀"
	
	var window_width = get_viewport().get_visible_rect().size.x
	var window_height = get_viewport().get_visible_rect().size.y
	
	
	# Force lockstep position before tween
	panel.position.x = window_width - panel.size.x
	toggle_button.position.x = panel.position.x - toggle_button.size.x

	var target_panel_x = window_width
	var target_button_x = window_width  - toggle_button.size.x

	var tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(panel, "position:x", target_panel_x, TWEEN_DURATION)
	tween.tween_property(toggle_button, "position:x", target_button_x, TWEEN_DURATION)

## Slide the UI menu in 
func slide_out() -> void: 
	if is_open: 
		return
		
	is_open = true
	toggle_button.text = "▶"
	
	var window_width = get_viewport().get_visible_rect().size.x
	var window_height = get_viewport().get_visible_rect().size.y
	
	toggle_button.position.x = panel.position.x - toggle_button.size.x
	
	
	var target_panel_x = window_width - panel.size.x
	var toggle_button_x = window_width - panel.size.x - toggle_button.size.x
	
	# Set parallel tweens for the ui panel and the p
	var tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(panel, "position:x", target_panel_x, TWEEN_DURATION)
	tween.tween_property(toggle_button, "position:x", toggle_button_x, TWEEN_DURATION)
	
	# Reenable inputs
	panel.process_mode = Node.PROCESS_MODE_INHERIT


func _sync_layout_position() -> void: 
	await get_tree().process_frame
	await get_tree().process_frame

	var window_width = get_viewport().get_visible_rect().size.x
	var window_height = get_viewport().get_visible_rect().size.y

	# Force panel layout boundary
	panel.position.x = window_width - panel.size.x
	
	# Position override
	toggle_button.position.x = panel.position.x - toggle_button.size.x
	toggle_button.position.y = (window_height / 2.0) - (toggle_button.size.y / 2.0)
